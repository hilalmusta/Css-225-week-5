# 25 Feb 2021
# check whether the numbers between 1 to 50 are divisible by 3 and 5

# for the numbers between 1 to 50
for i in range(50):
    # divisible by both
    if ((i+1)%3==0) and ((i+1)%5==0):
        print("Divisible by both")
    # divisible by 3
    elif (i+1)%3==0:
        print("Divisible by three")
    # divisible by 5
    elif (i+1)%5==0:
        print("Divisible by five")
    # f not divisible by 3 or 5
    else:
        print(i+1)