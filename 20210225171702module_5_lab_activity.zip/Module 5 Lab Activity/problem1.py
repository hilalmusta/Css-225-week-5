# 25 Feb 2021
# program that prints “Hello World” to the screen 100 times using a for loop.

# looping 100 times
for i in range(100):
    # printing hello world for every iterate
    print("Hello World")