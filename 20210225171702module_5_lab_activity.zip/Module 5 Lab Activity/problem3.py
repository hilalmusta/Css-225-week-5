# 25 Feb 2021
# count average of 10 numbers

# at first average is 0
avg = 0
for i in range(10):
    # String for getting input
    strL = "Enter the number " + str(i+1) +  " : "
    # getting the i th number as an input and converting into an integer
    num = int(input(strL))
    # calculating the total sum
    avg = avg + num
# printing average
print("Average: ",avg/10)
