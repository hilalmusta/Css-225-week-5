# 25 Feb 2021
# draw a square using given color

# importing turtle library
from turtle import *

# get color as an input
col = input("Enter the color: ")
# creating turtle
myTurt = Turtle()
# assigning color
myTurt.fillcolor(col)
# begin color filling
myTurt.begin_fill()
# for four sides of rectangle
for i in range(4):
    # go forward
    myTurt.forward(100)
    # turn right by 90
    myTurt.right(90)
# finish color filling
myTurt.end_fill()
# exit on close
done()